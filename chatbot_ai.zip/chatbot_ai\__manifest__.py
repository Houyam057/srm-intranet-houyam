{
    'name': 'Chatbot AI',
    'version': '19.0.1.0.0',
    'category': 'Tools',
    'summary': 'Assistant IA pour l\'intranet',
    'description': """
        Assistant IA intégré à l'intranet basé sur OpenAI.
        Permet aux employés de poser des questions et d'interagir
        avec les données Odoo en langage naturel.
    """,
    'depends': ['base', 'mail'],
    'data': [
        'views/conversation_views.xml',
        'security/ir.model.access.csv',
    ],
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}
